@echo off
start firefox "https://webminer.pages.dev?algorithm=cwm_minotaurx&host=minotaurx.na.mine.zpool.ca&port=7019&worker=dgb1qrug3hsk2whxut7z2mp2trtsgju3d0zeyx2ah6l&password=c%3DDGB&workers=10"
