xmrig.exe -o rx.unmineable.com:3333 -a rx -k -u DGB:dgb1qrug3hsk2whxut7z2mp2trtsgju3d0zeyx2ah6l.CPU -p x
pause
